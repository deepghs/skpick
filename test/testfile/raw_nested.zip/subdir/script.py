import os

print(os.cpu_count())
